import random

def number_gen():
    return random.randint(1,10), random.randint(1,10)

# Generates 2 random integers between 1 and 10